Free Bootstrap Resume/CV Template for developers

Theme name:
=======================================================================
Orbit

Theme version:
=======================================================================
v2.0

Release Date:
=======================================================================
15 July 2018

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media (https://themes.3rdwavemedia.com/)

Contact:
=======================================================================
Web: https://themes.3rdwavemedia.com/
Email: themes@3rdwavemedia.com
Twitter: @3rdwave_themes

License: 
=======================================================================
This template is free under the Creative Commons Attribution 3.0 License.
https://creativecommons.org/licenses/by/3.0/




